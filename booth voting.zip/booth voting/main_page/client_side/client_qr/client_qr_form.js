if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    // Start camera
    var onScreenVideo = document.getElementById("client_qr_CAMERA");
    var client_qr_USER_ID = document.getElementById("client_qr_USER_ID").readOnly = "true";

    var scanner = new Instascan.Scanner({
        video : onScreenVideo
    })

    Instascan.Camera.getCameras().then(function(cameras) {
        if (cameras.length > 1) {
            scanner.start(cameras[1]);
        }
        else if (cameras.length > 0) {
            scanner.start(cameras[0]);
        }
        else {
            console.error('No cameras found.');
        }
    })

    // Submitting text gained from qr code into database
    scanner.addListener('scan', function(input_value) {
        client_qr_USER_ID.value = input_value;

        document.forms[0].submit();
    })
} else {
    alert("Camera not supported.");
}

if(window.RTCPeerConnection) {
    // WebRTC supported
} else {
    alert("WebRTC not supported");
}