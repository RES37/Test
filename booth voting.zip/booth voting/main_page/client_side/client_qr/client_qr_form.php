<!-- Form for submitting scanned QR code -->
<form action="client_qr_action.php" method="post">
    <input type="text" name="client_qr_USER_ID" id="client_qr_USER_ID" style="display: none;">
</form>

<!-- Case of the qr scanner -->
<div id="main">
    <video id="client_qr_CAMERA"></video>
</div>