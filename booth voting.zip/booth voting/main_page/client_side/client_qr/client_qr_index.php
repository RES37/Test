<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../assets/css/side_bar.css">
    <link rel="stylesheet" href="../../assets/css/top_nav.css"> 
    <?php include_once '../../assets/php/nav_bar_css.php'; ?>

    <!-- JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/3.3.3/adapter.min.js"></script>
    <script type="text/javascript" src="https://rawcdn.githack.com/tobiasmuehl/instascan/4224451c49a701c04de7d0de5ef356dc1f701a93/bin/instascan.min.js"></script>
</head>

<body>
    <?php
        // Navigation bar
        include_once '../../assets/php/nav_bar.php';
    ?>

    <?php
        // Check if the user is logged in
        session_start();
        
        include_once 'client_qr_form.php';
    ?>
    
    <script type="text/javascript" src="client_qr_form.js"></script>
</body>
</html>
