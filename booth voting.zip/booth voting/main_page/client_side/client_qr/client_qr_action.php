<?php
use PHPMailer\PHPMailer\PHPMailer;

// Connect to database 
$db_host = "sql305.epizy.com";
$db_user = "epiz_34179086";
$db_pass = "PJ7nCuNYR8bJA75";
$db_name = "epiz_34179086_dbscanner";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// If database connection failed
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Checking if 'text' has any value
if(isset($_POST['client_qr_USER_ID'])) {
    $client_qr_USER_ID = $_POST['client_qr_USER_ID'];
    session_start();
    $_SESSION["client_qr_USER_ID"] = $client_qr_USER_ID;

    $update = "UPDATE tblattendance SET timeOut = now(), status = 1 WHERE status = 0 AND Id = '$client_qr_USER_ID';";

    // Insert the data into the database
    $result = mysqli_query($conn, "SELECT email FROM tbluser WHERE qrId = '$client_qr_USER_ID';");
    $email = mysqli_fetch_array($result);
    $bvs_survey = 123123;

    $res = mysqli_query($conn, "SELECT * FROM bvs_booths");
    // Store the results in an array
    $data = array();
    while ($row = mysqli_fetch_array($res)) {
        $data[] = $row;
    }

    try {
        if(mysqli_query($conn, $update)) {
            echo '<script language="javascript">
            alert("Timed Out Success")
            window.location.href="client_qr_index.php";
            </script>';

            sendmail($email, $bvs_survey);
            sendgmail($email, $bvs_survey);
            sendymail($email, $bvs_survey);
            function sendgmail($email, $bvs_survey)
            {
                require_once '../../assets/php/vendor/autoload.php';
                $mail = new PHPMailer();

                //SMTP Settings
                $mail->isSMTP();
                // $mail->SMTPDebug = 3;  Keep It commented this is used for debugging                          
                $mail->Host = "smtp.gmail.com"; // smtp address of your email
                $mail->SMTPAuth = true;
                $mail->Username = "personal.marcus7@gmail.com";
                $mail->Password = "hjlxtrejfulgbqoh";
                $mail->Port = 587;  // port
                $mail->SMTPSecure = "tls";  // tls or ssl
                $mail->smtpConnect([
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ]);

                //Email Settings
                $mail->isHTML(true);
                $mail->setFrom("personal.marcus7@gmail.com", "demoQratic");
                $mail->addAddress($email); // enter email address whom you want to send
                $mail->Subject = ("STI SHS EXPO 2023: Who do you think the Best Booth is?");
                $mail->Body = $bvs_survey;
                if (!$mail->send()) {
                    echo "Something is wrong: <br><br>" . $mail->ErrorInfo;
                }
            }

            function sendmail($email, $bvs_survey)
            {
                require_once '../../assets/php/vendor/autoload.php';
                $mail = new PHPMailer();

                //SMTP Settings
                $mail->isSMTP();
                // $mail->SMTPDebug = 3;  Keep It commented this is used for debugging                          
                $mail->Host = "smtp.office365.com"; // smtp address of your email
                $mail->SMTPAuth = true;
                $mail->Username = "personal.marcus7@gmail.com";
                $mail->Password = "hjlxtrejfulgbqoh";
                $mail->Port = 587;  // port
                $mail->SMTPSecure = "tls";  // tls or ssl
                $mail->smtpConnect([
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ]);

                //Email Settings
                $mail->isHTML(true);
                $mail->setFrom("personal.marcus7@gmail.com", "demoQratic");
                $mail->addAddress($email); // enter email address whom you want to send
                $mail->Subject = ("STI SHS EXPO 2023: Who do you think the Best Booth is?");
                $mail->Body = $bvs_survey;
                if (!$mail->send()) {
                    echo "Something is wrong: <br><br>" . $mail->ErrorInfo;
                }
            }
                
            function sendymail($email, $bvs_survey)
            {

                require_once '../../assets/php/vendor/autoload.php';
                $mail = new PHPMailer();

                //SMTP Settings
                $mail->isSMTP();
                // $mail->SMTPDebug = 3;  Keep It commented this is used for debugging                          
                $mail->Host = "smtp.mail.yahoo.com"; // smtp address of your email
                $mail->SMTPAuth = true;
                $mail->Username = "personal.marcus7@gmail.com";
                $mail->Password = "hjlxtrejfulgbqoh";
                $mail->Port = 587;  // port
                $mail->SMTPSecure = "tls";  // tls or ssl
                $mail->smtpConnect([
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ]);

                //Email Settings
                $mail->isHTML(true);
                $mail->setFrom("personal.marcus7@gmail.com", "demoQratic");
                $mail->addAddress($email); // enter email address whom you want to send
                $mail->Subject = ("STI SHS EXPO 2023: Who do you think the Best Booth is?");
                $mail->Body = $bvs_survey;
                if (!$mail->send()) {
                    echo "Something is wrong: <br><br>" . $mail->ErrorInfo;
                }
            }
            exit();
        } else {  
            echo '<script language="javascript">
            alert("Error!")
            window.location.href="client_qr_index.php";
            </script>';
        }
    }
    catch(mysqli_sql_exception $e) {
        echo '<script language="javascript">
        alert("Error!")
        window.location.href="client_qr_index.php";
        </script>';
    }
}

// Clossing connection to database
mysqli_close($conn);
?>
