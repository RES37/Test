<?php 
// Connect to database
$db_host = "sql305.epizy.com";
$db_user = "epiz_34179086";
$db_pass = "PJ7nCuNYR8bJA75";
$db_name = "epiz_34179086_dbscanner";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// If database connection failed
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the form data
$booth_strand = $_POST['booth_strand'];
$booth_username = $_POST['booth_username'];
session_start();
$user_id = $_SESSION['client_qr_USER_ID'];

$sql = "INSERT INTO bvs_scanned_users (fk_booth_id, fk_user_id)
VALUES('SELECT booth_id FROM bvs_booths JOIN bvs_scanned_users ON bvs_booths.booth_id = bvs_scanned_users.fk_booth_id WHERE booth_strand = '$booth_strand' AND booth_username = '$booth_username'','$user_id')";

try {
    if(mysqli_query($conn, $sql)) {
        echo '<script language="javascript">
            alert("Voting Success")
            window.location.href="client_survey_index.php";
            </script>';
    } else {
        echo '<script language="javascript">
            alert("Voting Success")
            window.location.href="client_survey_index.php";
            </script>';
    }
} catch(mysqli_sql_exception $e) {
    echo '<script language="javascript">
    alert("Voting Success")
    window.location.href="client_survey_index.php";
    </script>';
}

// Clossing connection to database
mysqli_close($conn);
?>
