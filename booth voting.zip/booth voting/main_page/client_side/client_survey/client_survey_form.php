<div id="container">
        <h1>Who's the Best Booth for you?</h1>
        
        <form action="client_survey_action.php" method="post">
            <select>
                <?php
                    session_start();
                    
                    foreach($data as $row) {
                        echo "<option><span id=\"booth_strand\">{$row['booth_strand']}</span> - <span id=\"booth_username\">{$row['booth_username']}</span></option>";
                    }
                ?>
            </select>

            <input type="submit" value="Submit"></input>
        </form>
</div>