<?php 

// Connect to database
$db_host = "sql305.epizy.com";
$db_user = "epiz_34179086";
$db_pass = "PJ7nCuNYR8bJA75";
$db_name = "epiz_34179086_dbscanner";

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// If database connection failed
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

// Get the form data
$server_register_STRAND = $_POST['server_register_STRAND'];
$server_register_USERNAME = $_POST['server_register_USERNAME'];

// Insert the data into the database
$sql = "INSERT INTO bvs_booths (booth_strand, booth_username) VALUES('$server_register_STRAND', '$server_register_USERNAME')";

try {
	if (mysqli_query($conn, $sql)) {

		echo '<script language="javascript">
		alert("Registration Successful")
		window.location.href="../server_register/server_register_index.php";
		</script>';
		exit();
	} else {
		echo '<script language="javascript">
		alert("Error! Booth already existing")
		window.location.href="../server_register/server_register_index.php";
		</script>';
	}
} catch(mysqli_sql_exception $e) {
	echo '<script language="javascript">
    alert("Error! Booth already existing")
    window.location.href="../server_register/server_register_index.php";
    </script>';
}

mysqli_close($conn);

?>
