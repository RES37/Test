<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <!-- Assets -->
  <link rel="stylesheet" href="../../assets/css/form_index.css">
  <link rel="stylesheet" href="../../assets/css/top_nav.css">
  <?php include_once '../../assets/php/nav_bar_css.php'; ?>
</head>

<body>
  <?php
    include_once '../../assets/php/nav_bar.php';
  ?>

  <?php
    session_start();
    session_unset();
    session_destroy();

    include_once 'server_login_form.php';
  ?>
</body>
</html>
