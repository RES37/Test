<div id="container">
<button class="btn" onClick="window.location.href='index.php';"><i class="fa fa-home"></i></button>
    <h1>Admin</h1>
        <label>
            <a href="../server_register/server_register_index.php">
                <input type="button" name="admin_features" value="Booth Register">
                <span>Booth Register</span>
            </a>
        </label>
        
        <label>
            <a href="../server_report/server_report_index.php">
                <input type="button" name="admin_features" value="Booth Report">
                <span>Booth Report</span>
            </a>
        </label>
</div>