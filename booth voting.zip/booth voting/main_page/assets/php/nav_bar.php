<header>
    <nav>
        <div class="topnav" id="topnav">
            <a class="split1">demoQratic</a>
            <a class="active1" href="../../../landing_page/client_side/index.php" onclick="if (!confirm('Are you sure?')) return false;">Home</a>
        </div>
    </nav>
</header>

<script>
    window.onscroll = function() {
        var currentScrollPos = window.pageYOffset;

        // 20 is an arbitrary number here, just to make you think if you need the prevScrollpos variable:
        if (currentScrollPos > 20) {
            // I am using 'display' instead of 'top':
            document.getElementById("topnav").style.display = "none";
        } else {
            document.getElementById("topnav").style.display = "initial";
        }
    }
</script>