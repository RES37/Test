<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>User</title>
        <!-- Assets -->
        <link rel="stylesheet" href="../assets/css/client_side.css">
        <link rel="stylesheet" href="../assets/css/top_nav.css">
        <link rel="icon" type="image/x-icon" href="../assets/img/favicon.png">
        <script src="../assets/js/client_side.js"></script>
        <?php include_once '../assets/php/nav_bar_css.php'; ?>
    </head>

    <body>
        <div id="containerLoader" class="containerLoader">
            <div class="lds-ripple">
                <div></div>
                <div></div>
            </div>
        </div>
        
        <?php
            include_once '../assets/php/nav_bar.php';
        ?>

        <!-- Research Description -->
        <section class="research_description">
            
            <img class="levitate" src="../assets/img/bg_image.png" alt="image"/>

            <div class="title_container">
                WEB-BASED BOOTH VOTING SYSTEM UTILIZING QR TECHNOLOGY
            </div>

            <div class="content_container">
                    The web-based booth voting system utilizing QR technology is a project aimed at creating an efficient and user-friendly voting system for use in the STI College Marikina Exposition.
                    By utilizing their smartphones or other mobile devices to scan a special QR code that has been issued, voters can use the system to cast their votes online.
                    This project guarantees a safe and accurate voting procedure, doing away with the necessity for manual vote counting and lowering the possibility of fraud or human error. 
            </div><br>

            <a class="login_button" href="../../main_page/client_side/client_qr/client_qr_index.php">LOGIN</a>
        </section>

        <!-- Vision & Mission Description -->
        <section id="vision_mission" class="vision_mission_description">
            <div class="about_us">About Us</div>
            <hr width="20%"><br>
            
            <div class="about_us_description">This project was started by a dedicated research group consisting of 5 members that are currently taking the senior high school course of Information Technology in Mobile App and Web Development. We are conducting and prototyping a web-based system that utilizes QR technology to tabulate data and showcase it with graphical visualizations.</div>
            
            <div class="vm_container">
                <div class="vision_container">
                    <div class="vision_title">Vision</div>
                    <hr width="20%"><br>
                    <div class="vision_content">
                        To establish ourselves as highly competent and innovative providers of top-quality products for the industry of information technology. Providing businesses of all shapes and sizes
                        with effective systems while maintaining equal services for all workers and consumers.
                    </div>
                </div>

                <div class="mission_container">
                    <div class="mission_title">Mission</div>
                    <hr width="20%"><br>
                    <div class="mission_content">
                    <span onclick="location.href='../../main_page/server_side/server_login/index.php'" style="text-decoration: none;">Our</span> mission is to be able to provide authentic, reliable, and user-friendly systems while pursuing our services with the utmost enthusiasm and making use of the latest technology
                        the industry has to offer in order to help everyone achieve their goals.
                    </div>
                </div>
            </div>
        </section>

        <!-- Vision & Mission Description -->
        <section id="meet_the_team" class="meet_the_team_description">
            <hr width="90%">
            <div class="meet_the_team">Meet the Team</div>
            <hr width="20%"><br>
            
            <div class="row">
                <div class="column">
                    <div class="card">
                        <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/aaf67f04-172c-44a7-a105-f41477cfd6c4/ddisc5n-42f4d6b0-4987-462a-99ae-5a8cdd3e73ab.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2FhZjY3ZjA0LTE3MmMtNDRhNy1hMTA1LWY0MTQ3N2NmZDZjNFwvZGRpc2M1bi00MmY0ZDZiMC00OTg3LTQ2MmEtOTlhZS01YThjZGQzZTczYWIuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.Iqk6OjFHW3BGZuQrc3rnEM3-buIqdZm_3MK9gEgmnQE" alt="Jane" style="width:100%">
                        <div class="container">
                            <h2>Marcus Dex Vibar</h2>
                            <p class="title">Project Manager | Full Stack Developer</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                    </div>
                </div>

                <div class="column">
                    <div class="card">
                        <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/aaf67f04-172c-44a7-a105-f41477cfd6c4/ddisc5n-42f4d6b0-4987-462a-99ae-5a8cdd3e73ab.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2FhZjY3ZjA0LTE3MmMtNDRhNy1hMTA1LWY0MTQ3N2NmZDZjNFwvZGRpc2M1bi00MmY0ZDZiMC00OTg3LTQ2MmEtOTlhZS01YThjZGQzZTczYWIuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.Iqk6OjFHW3BGZuQrc3rnEM3-buIqdZm_3MK9gEgmnQE" alt="Mike" style="width:100%">
                        <div class="container">
                            <h2>Jairus Rain Mendoza</h2>
                            <p class="title">Assitant Project Manager | Front End Dev</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                    </div>
                </div>
                
                <div class="column">
                    <div class="card">
                        <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/aaf67f04-172c-44a7-a105-f41477cfd6c4/ddisc5n-42f4d6b0-4987-462a-99ae-5a8cdd3e73ab.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2FhZjY3ZjA0LTE3MmMtNDRhNy1hMTA1LWY0MTQ3N2NmZDZjNFwvZGRpc2M1bi00MmY0ZDZiMC00OTg3LTQ2MmEtOTlhZS01YThjZGQzZTczYWIuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.Iqk6OjFHW3BGZuQrc3rnEM3-buIqdZm_3MK9gEgmnQE" alt="John" style="width:100%">
                        <div class="container">
                            <h2>Justin Luague</h2>
                            <p class="title">Lead Documentarian</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                    </div>
                </div>

                <div class="column">
                    <div class="card">
                        <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/aaf67f04-172c-44a7-a105-f41477cfd6c4/ddisc5n-42f4d6b0-4987-462a-99ae-5a8cdd3e73ab.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2FhZjY3ZjA0LTE3MmMtNDRhNy1hMTA1LWY0MTQ3N2NmZDZjNFwvZGRpc2M1bi00MmY0ZDZiMC00OTg3LTQ2MmEtOTlhZS01YThjZGQzZTczYWIuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.Iqk6OjFHW3BGZuQrc3rnEM3-buIqdZm_3MK9gEgmnQE" alt="John" style="width:100%">
                        <div class="container">
                            <h2>Leonard Dave Mendoza</h2>
                            <p class="title">Documentarian</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                    </div>
                </div>

                <div class="column">
                    <div class="card">
                        <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/aaf67f04-172c-44a7-a105-f41477cfd6c4/ddisc5n-42f4d6b0-4987-462a-99ae-5a8cdd3e73ab.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2FhZjY3ZjA0LTE3MmMtNDRhNy1hMTA1LWY0MTQ3N2NmZDZjNFwvZGRpc2M1bi00MmY0ZDZiMC00OTg3LTQ2MmEtOTlhZS01YThjZGQzZTczYWIuanBnIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.Iqk6OjFHW3BGZuQrc3rnEM3-buIqdZm_3MK9gEgmnQE" alt="John" style="width:100%">
                        <div class="container">
                            <h2>Lisandro Zabalo</h2>
                            <p class="title">Documentarian</p>
                            <p><button class="button">Contact</button></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </body>
</html>
