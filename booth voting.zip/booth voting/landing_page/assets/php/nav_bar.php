<header>
    <nav>
        <div class="topnav" id="topnav">
            <a class="split1">demoQratic</a>
            <a href="../../../index.php" onclick="if (!confirm('Are you sure?')) return false;">Home</a>
            <a href="index.php#vision_mission" id="nav_hide">About Us</a>
            <a href="index.php#meet_the_team" id="nav_hide">Meet the Team</a>
            
            <?php
                session_start();
                
                if(isset($_SESSION['booth_id']) || isset($_SESSION['booth_username'])) {
                    echo "<button class=\"openbtn\" onclick=\"openNav()\">&#9776</button>";
                }
            ?>
        </div>
    </nav>
</header>